import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { FiolesGame } from "./components/FiolesGame";
import "./styles.css";

const root = document.getElementById("root");
if (!root) throw new Error("racine absente");

createRoot(root).render(
  <StrictMode>
    <FiolesGame />
  </StrictMode>,
);
