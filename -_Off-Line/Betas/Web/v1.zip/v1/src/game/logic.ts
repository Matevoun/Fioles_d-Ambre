/*
 * DOCTRINE OBLIGATOIRE
 * Avant toute modification de ce jeu (humain ou IA), lire doc/DOCTRINE.md
 * Ne pas changer la regle unique. Ne pas monetiser. Ne pas retirer les credits.
 * Version : 1
 *
 * Regle, generation, courbe. Pas de DOM ici.
 */

export const CAPACITY = 4;

export type Segment = { color: number; hidden: boolean };
export type Vial = Segment[];
export type Move = { from: number; to: number };

export type Slug = { color: number; hidden: boolean; h: number };

export type Melasse = {
  name: string;
  fill: string;
  deep: string;
  light: string;
  motif: "bubble" | "slash" | "dot" | "chevron" | "ring" | "wave" | "speck" | "diamond";
};

export const MELASSES: Melasse[] = [
  { name: "Ambre", fill: "#e39b2b", deep: "#8a5410", light: "#ffd27a", motif: "bubble" },
  { name: "Grenat", fill: "#c4375a", deep: "#6e1830", light: "#ff9ab4", motif: "slash" },
  { name: "Emeraude", fill: "#1f9a6c", deep: "#0c5a3e", light: "#8ef0c8", motif: "dot" },
  { name: "Indigo", fill: "#3d4ad4", deep: "#1e267f", light: "#aeb6ff", motif: "chevron" },
  { name: "Orchidee", fill: "#c43b93", deep: "#721c54", light: "#ffb0de", motif: "ring" },
  { name: "Lagon", fill: "#1aa3b5", deep: "#0b616c", light: "#9af0f8", motif: "wave" },
  { name: "Absinthe", fill: "#a3c43a", deep: "#5c7014", light: "#e7f7a4", motif: "speck" },
  { name: "Violette", fill: "#7a3bb8", deep: "#451c70", light: "#d7b4ff", motif: "diamond" },
  { name: "Corail", fill: "#e56a3c", deep: "#9a3814", light: "#ffc0a4", motif: "slash" },
  { name: "Bleuet", fill: "#3a78e0", deep: "#1a448f", light: "#b7d2ff", motif: "dot" },
  { name: "Prune", fill: "#8a3d5b", deep: "#4e2032", light: "#e7b0c4", motif: "ring" },
  { name: "Safran", fill: "#e2c14a", deep: "#8f7410", light: "#fff1b0", motif: "wave" },
];

export type Spec = {
  colors: number;
  empties: number;
  hidden: boolean;
  scramble: number;
};

export function specFor(level: number): Spec {
  const n = Math.max(1, Math.floor(level));
  if (n === 1) return { colors: 3, empties: 2, hidden: false, scramble: 3 };
  if (n === 2) return { colors: 3, empties: 2, hidden: false, scramble: 5 };
  if (n === 3) return { colors: 3, empties: 2, hidden: false, scramble: 8 };
  if (n <= 6) return { colors: 4, empties: 2, hidden: false, scramble: 10 + (n - 4) * 3 };
  if (n <= 10) return { colors: 5, empties: 2, hidden: false, scramble: 12 + (n - 7) * 2 };
  if (n <= 14) return { colors: 5, empties: 1, hidden: false, scramble: 10 + (n - 11) };
  if (n <= 18) return { colors: 6, empties: 2, hidden: false, scramble: 14 + (n - 15) * 2 };
  if (n <= 22) return { colors: 6, empties: 1, hidden: false, scramble: 12 + (n - 19) * 2 };
  if (n <= 26) return { colors: 7, empties: 2, hidden: true, scramble: 16 + (n - 23) * 2 };
  if (n <= 30) return { colors: 7, empties: 1, hidden: true, scramble: 14 + (n - 27) * 2 };
  if (n <= 34) return { colors: 8, empties: 2, hidden: true, scramble: 18 + (n - 31) * 2 };
  if (n <= 40) return { colors: 8, empties: 1, hidden: true, scramble: 16 + Math.floor((n - 35) * 1.2) };
  const extra = Math.min(4, Math.floor((n - 41) / 6));
  return { colors: 9 + extra, empties: 1, hidden: true, scramble: 18 + extra * 2 };
}

export function bandLabel(spec: Spec): string {
  const mel = `${spec.colors} melasses`;
  const empty = spec.empties > 1 ? `${spec.empties} fioles vides` : "une fiole vide";
  const veil = spec.hidden ? ", couches voilees" : "";
  return `${mel}, ${empty}${veil}`;
}

export function cloneVials(vials: Vial[]): Vial[] {
  return vials.map((v) => v.map((s) => ({ color: s.color, hidden: s.hidden })));
}

function revealVialTop(vial: Vial) {
  if (vial.length === 0) return;
  const color = vial[vial.length - 1].color;
  vial[vial.length - 1].hidden = false;
  for (let i = vial.length - 2; i >= 0; i--) {
    if (vial[i].color !== color) break;
    vial[i].hidden = false;
  }
}

export function topRun(vial: Vial): { color: number; count: number } | null {
  if (vial.length === 0) return null;
  const color = vial[vial.length - 1].color;
  if (vial[vial.length - 1].hidden) return null;
  let count = 1;
  for (let i = vial.length - 2; i >= 0; i--) {
    if (vial[i].color !== color || vial[i].hidden) break;
    count++;
  }
  return { color, count };
}

export function isSealed(vial: Vial): boolean {
  if (vial.length !== CAPACITY) return false;
  const c = vial[0].color;
  return vial.every((s) => s.color === c && !s.hidden);
}

export function isWon(vials: Vial[]): boolean {
  return vials.every((v) => v.length === 0 || isSealed(v));
}

export function runCount(vials: Vial[]): number {
  let n = 0;
  for (const v of vials) {
    let prev = -1;
    for (const s of v) {
      if (s.color !== prev) {
        n++;
        prev = s.color;
      }
    }
  }
  return n;
}

export function pour(vials: Vial[], from: number, to: number, respectSeal = true): Vial[] | null {
  if (from === to) return null;
  if (from < 0 || to < 0 || from >= vials.length || to >= vials.length) return null;
  const src = vials[from];
  const dst = vials[to];
  if (src.length === 0) return null;
  if (respectSeal && isSealed(src)) return null;
  const run = topRun(src);
  if (!run) return null;
  const space = CAPACITY - dst.length;
  if (space <= 0) return null;
  if (dst.length > 0) {
    const top = dst[dst.length - 1];
    if (top.hidden || top.color !== run.color) return null;
  }
  const k = Math.min(run.count, space);
  const next = cloneVials(vials);
  const moved = next[from].splice(next[from].length - k, k).map((s) => ({
    color: s.color,
    hidden: false,
  }));
  if (next[from].length > 0) revealVialTop(next[from]);
  next[to].push(...moved);
  return next;
}

function moveTop(vials: Vial[], from: number, to: number, k: number): Vial[] {
  const next = cloneVials(vials);
  const moved = next[from].splice(next[from].length - k, k);
  next[to].push(...moved);
  return next;
}

function sameColors(a: Vial[], b: Vial[]): boolean {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) {
    if (a[i].length !== b[i].length) return false;
    for (let j = 0; j < a[i].length; j++) {
      if (a[i][j].color !== b[i][j].color) return false;
    }
  }
  return true;
}

export function veil(vials: Vial[]): Vial[] {
  return vials.map((v) => {
    if (v.length === 0) return [];
    const top = v[v.length - 1].color;
    let run = 1;
    for (let i = v.length - 2; i >= 0; i--) {
      if (v[i].color !== top) break;
      run++;
    }
    const visibleFrom = v.length - run;
    return v.map((s, i) => ({ color: s.color, hidden: i < visibleFrom }));
  });
}

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function findUnsolve(
  vials: Vial[],
  rng: () => number,
): { earlier: Vial[]; forward: Move } | null {
  const n = vials.length;
  const options: { earlier: Vial[]; forward: Move }[] = [];
  for (let d = 0; d < n; d++) {
    const run = topRun(vials[d]);
    if (!run) continue;
    for (let s = 0; s < n; s++) {
      if (s === d) continue;
      const space = CAPACITY - vials[s].length;
      const maxK = Math.min(run.count, space);
      for (let k = 1; k <= maxK; k++) {
        const earlier = moveTop(vials, d, s, k);
        const restored = pour(earlier, s, d, false);
        if (!restored) continue;
        if (!sameColors(restored, vials)) continue;
        if (runCount(earlier) <= runCount(vials)) continue;
        options.push({ earlier, forward: { from: s, to: d } });
      }
    }
  }
  if (options.length === 0) return null;
  return options[Math.floor(rng() * options.length)];
}

function permuteLevel(
  vials: Vial[],
  solution: Move[],
  rng: () => number,
): { vials: Vial[]; solution: Move[] } {
  const n = vials.length;
  const perm = Array.from({ length: n }, (_, i) => i);
  for (let i = n - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = perm[i];
    perm[i] = perm[j];
    perm[j] = tmp;
  }
  const inv = new Array<number>(n);
  perm.forEach((old, neu) => {
    inv[old] = neu;
  });
  return {
    vials: perm.map((old) => vials[old]),
    solution: solution.map((m) => ({ from: inv[m.from], to: inv[m.to] })),
  };
}

export type Level = {
  level: number;
  spec: Spec;
  vials: Vial[];
  solution: Move[];
};

function scramble(spec: Spec, seed: number): { vials: Vial[]; solution: Move[] } {
  const rng = mulberry32(seed);
  let vials: Vial[] = [];
  for (let c = 0; c < spec.colors; c++) {
    const tube: Vial = [];
    for (let i = 0; i < CAPACITY; i++) tube.push({ color: c, hidden: false });
    vials.push(tube);
  }
  for (let e = 0; e < spec.empties; e++) vials.push([]);
  const stack: Move[] = [];
  let guard = 0;
  while (stack.length < spec.scramble && guard < spec.scramble * 30) {
    guard++;
    const step = findUnsolve(vials, rng);
    if (!step) break;
    vials = step.earlier;
    stack.push(step.forward);
  }
  const solution = stack.reverse();
  const mixed = permuteLevel(vials, solution, rng);
  return {
    vials: spec.hidden ? veil(mixed.vials) : mixed.vials,
    solution: mixed.solution,
  };
}

export function generateLevel(level: number): Level {
  const spec = specFor(level);
  let best: { vials: Vial[]; solution: Move[] } | null = null;
  for (let salt = 0; salt < 24; salt++) {
    const made = scramble(spec, level * 9973 + salt * 131 + 17);
    if (isWon(made.vials)) continue;
    if (!replayWins(made.vials, made.solution)) continue;
    if (!best || made.solution.length > best.solution.length) best = made;
    if (made.solution.length >= spec.scramble) break;
  }
  if (best) return { level, spec, vials: best.vials, solution: best.solution };
  const fallback = scramble(spec, level * 9973 + 17);
  return { level, spec, vials: fallback.vials, solution: fallback.solution };
}

export function replayWins(start: Vial[], solution: Move[]): boolean {
  let cur = cloneVials(start);
  for (const m of solution) {
    const next = pour(cur, m.from, m.to, true);
    if (!next) return false;
    cur = next;
  }
  return isWon(cur);
}

export function legalMoves(vials: Vial[]): Move[] {
  const out: Move[] = [];
  for (let from = 0; from < vials.length; from++) {
    for (let to = 0; to < vials.length; to++) {
      if (pour(vials, from, to, true)) out.push({ from, to });
    }
  }
  return out;
}

function scoreMove(vials: Vial[], m: Move): number {
  const next = pour(vials, m.from, m.to, true);
  if (!next) return -9999;
  let s = 0;
  if (isSealed(next[m.to])) s += 50;
  s += (runCount(vials) - runCount(next)) * 20;
  const src = vials[m.from];
  const cut = src.length - (next[m.from].length);
  const under = src[src.length - cut - 1];
  if (under?.hidden) s += 8;
  if (vials[m.to].length === 0) s -= 12;
  const mono = src.length > 0 && src.every((seg) => seg.color === src[0].color && !seg.hidden);
  if (mono && !isSealed(next[m.to])) s -= 25;
  return s;
}

export function hintMove(vials: Vial[]): Move | null {
  if (isWon(vials)) return null;
  const colors = new Set<number>();
  for (const v of vials) for (const s of v) colors.add(s.color);
  if (colors.size <= 6) {
    const found = bfsFirst(vials, 6000);
    if (found) return found;
  }
  const moves = legalMoves(vials);
  if (moves.length === 0) return null;
  let best = moves[0];
  let bestScore = scoreMove(vials, best);
  for (const m of moves) {
    const sc = scoreMove(vials, m);
    if (sc > bestScore) {
      best = m;
      bestScore = sc;
    }
  }
  return best;
}

function bfsFirst(vials: Vial[], cap: number): Move | null {
  const keyOf = (vs: Vial[]) =>
    vs.map((v) => v.map((s) => `${s.color}${s.hidden ? "?" : ""}`).join(",")).join("|");
  const q: { vials: Vial[]; first: Move | null }[] = [{ vials, first: null }];
  const seen = new Set<string>([keyOf(vials)]);
  let nodes = 0;
  while (q.length > 0 && nodes < cap) {
    const cur = q.shift();
    if (!cur) break;
    nodes++;
    for (const m of legalMoves(cur.vials)) {
      const next = pour(cur.vials, m.from, m.to, true);
      if (!next) continue;
      const k = keyOf(next);
      if (seen.has(k)) continue;
      seen.add(k);
      const first = cur.first ?? m;
      if (isWon(next)) return first;
      q.push({ vials: next, first });
    }
  }
  return null;
}

function revealSlugs(src: Slug[]) {
  if (src.length === 0) return;
  const color = src[src.length - 1].color;
  src[src.length - 1].hidden = false;
  for (let i = src.length - 2; i >= 0; i--) {
    if (src[i].color !== color) break;
    src[i].hidden = false;
  }
}

export function slugsAfterShave(vial: Vial, units: number): Slug[] {
  const src: Slug[] = vial.map((s) => ({ color: s.color, hidden: s.hidden, h: 1 }));
  let left = units;
  while (left > 0.001 && src.length > 0) {
    const top = src[src.length - 1];
    const d = Math.min(top.h, left);
    top.h -= d;
    left -= d;
    if (top.h <= 0.001) src.pop();
  }
  revealSlugs(src);
  return src.filter((b) => b.h > 0.02);
}

export function slugsGrow(vial: Vial, color: number, units: number): Slug[] {
  const slugs = slugsAfterShave(vial, 0);
  if (units <= 0.001) return slugs;
  const top = slugs[slugs.length - 1];
  if (top && !top.hidden && top.color === color) top.h += units;
  else slugs.push({ color, hidden: false, h: units });
  return slugs;
}

export function selfTest(): { ok: boolean; lines: string[] } {
  const lines: string[] = [];
  const fail = (m: string) => lines.push(`FAIL ${m}`);

  const blocked = pour(
    [[{ color: 0, hidden: false }], [{ color: 1, hidden: false }]],
    0,
    1,
    true,
  );
  if (blocked) fail("couleur differente acceptee");

  const sealed = pour(
    [
      [
        { color: 0, hidden: false },
        { color: 0, hidden: false },
        { color: 0, hidden: false },
        { color: 0, hidden: false },
      ],
      [],
    ],
    0,
    1,
    true,
  );
  if (sealed) fail("fiole bouchee versee");

  for (const level of [1, 2, 3, 6, 12, 20, 24, 36]) {
    const made = generateLevel(level);
    const wins = replayWins(made.vials, made.solution);
    lines.push(
      `niveau ${level} : ${made.solution.length} coups, ${made.spec.colors} couleurs, voile ${made.spec.hidden ? "oui" : "non"}, gagne ${wins ? "oui" : "non"}`,
    );
    if (!wins) fail(`solution niveau ${level}`);
    if (isWon(made.vials)) fail(`deja gagne ${level}`);
    if (level === 1 && (made.solution.length < 2 || made.solution.length > 6)) {
      fail(`niveau 1 trop long ou trop court (${made.solution.length})`);
    }
  }

  const again = generateLevel(4);
  const twice = generateLevel(4);
  const same =
    again.vials.length === twice.vials.length &&
    again.vials.every((v, i) => sameColors([v], [twice.vials[i]]));
  if (!same) fail("niveau non deterministe");

  const ok = lines.every((l) => !l.startsWith("FAIL"));
  return { ok, lines };
}
