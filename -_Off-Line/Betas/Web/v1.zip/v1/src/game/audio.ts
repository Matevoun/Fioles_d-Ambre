/*
 * DOCTRINE OBLIGATOIRE
 * Avant toute modification de ce jeu (humain ou IA), lire doc/DOCTRINE.md
 * Ne pas changer la regle unique. Ne pas monetiser. Ne pas retirer les credits.
 * Version : 1
 */

export type Mixer = {
  unlock: () => void;
  pour: () => void;
  select: () => void;
  deny: () => void;
  cork: () => void;
  win: () => void;
  setMuted: (muted: boolean) => void;
};

export function createMixer(): Mixer {
  let ctx: AudioContext | null = null;
  let master: GainNode | null = null;
  let pourBuf: AudioBuffer | null = null;
  let muted = false;

  function ensure() {
    if (ctx) return;
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.8;
    master.connect(ctx.destination);
    const frames = Math.floor(ctx.sampleRate * 0.38);
    pourBuf = ctx.createBuffer(1, frames, ctx.sampleRate);
    const data = pourBuf.getChannelData(0);
    for (let i = 0; i < frames; i++) {
      const env = Math.sin((i / frames) * Math.PI);
      data[i] = (Math.random() * 2 - 1) * env;
    }
  }

  function bus() {
    ensure();
    if (ctx && ctx.state === "suspended") void ctx.resume();
    return { ctx: ctx!, master: master! };
  }

  function tone(freq: number, dur: number, type: OscillatorType, gain: number) {
    if (muted) return;
    const { ctx: ac, master: out } = bus();
    const osc = ac.createOscillator();
    const g = ac.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, ac.currentTime);
    g.gain.exponentialRampToValueAtTime(gain, ac.currentTime + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + dur);
    osc.connect(g);
    g.connect(out);
    osc.start();
    osc.stop(ac.currentTime + dur + 0.02);
  }

  return {
    unlock() {
      const { ctx: ac } = bus();
      if (ac.state === "suspended") void ac.resume();
    },
    setMuted(next) {
      muted = next;
      if (master) master.gain.setTargetAtTime(next ? 0 : 0.8, master.context.currentTime, 0.02);
    },
    pour() {
      if (muted || !pourBuf) {
        if (!muted) bus();
        if (muted || !pourBuf) return;
      }
      const { ctx: ac, master: out } = bus();
      const src = ac.createBufferSource();
      src.buffer = pourBuf;
      src.playbackRate.value = 0.75 + Math.random() * 0.2;
      const filter = ac.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 380;
      const g = ac.createGain();
      g.gain.value = 0.45;
      src.connect(filter);
      filter.connect(g);
      g.connect(out);
      src.start();
    },
    select() {
      tone(540, 0.07, "sine", 0.08);
    },
    deny() {
      tone(130, 0.14, "triangle", 0.07);
    },
    cork() {
      tone(220, 0.09, "square", 0.04);
    },
    win() {
      tone(392, 0.4, "sine", 0.08);
      window.setTimeout(() => tone(494, 0.4, "sine", 0.08), 120);
      window.setTimeout(() => tone(587, 0.55, "sine", 0.09), 240);
    },
  };
}
