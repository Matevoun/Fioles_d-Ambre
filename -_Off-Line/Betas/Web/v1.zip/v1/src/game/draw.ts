/*
 * DOCTRINE OBLIGATOIRE
 * Avant toute modification de ce jeu (humain ou IA), lire doc/DOCTRINE.md
 * Ne pas changer la regle unique. Ne pas monetiser. Ne pas retirer les credits.
 * Version : 1
 *
 * Verre et melasse dessines ici. Pas de sprite de liquide.
 */

import { CAPACITY, MELASSES, type Slug } from "./logic";

export type VialLayout = {
  index: number;
  x: number;
  y: number;
  w: number;
  h: number;
};

export type DrawFrame = {
  slugs: Slug[][];
  sealed: boolean[];
  selected: number | null;
  shakeIndex: number | null;
  shakeP: number;
  hint: { from: number; to: number } | null;
  stream: { from: number; to: number; color: number; p: number } | null;
  corkP: number | null;
  corkIndex: number | null;
  time: number;
  won: boolean;
};

const INK = "#140e16";
const LAMP = "#e7a24a";
const PARCHMENT = "#f6ecdf";

export function layoutVials(count: number, w: number, h: number): VialLayout[] {
  const rows = count > 6 ? 2 : 1;
  const cols = Math.ceil(count / rows);
  const padX = 14;
  const padY = 16;
  const slotW = (w - padX * 2) / cols;
  const slotH = (h - padY * 2) / rows;
  const vialW = Math.max(36, Math.min(slotW * 0.62, 74));
  const vialH = Math.max(120, Math.min(slotH * 0.86, vialW * 3.35));
  const out: VialLayout[] = [];
  for (let i = 0; i < count; i++) {
    const row = Math.floor(i / cols);
    const col = i % cols;
    const inRow = Math.min(cols, count - row * cols);
    const rowWidth = inRow * slotW;
    const originX = (w - rowWidth) / 2;
    out.push({
      index: i,
      x: originX + col * slotW + slotW / 2,
      y: padY + row * slotH + (slotH - vialH) / 2,
      w: vialW,
      h: vialH,
    });
  }
  return out;
}

export function hitTest(layouts: VialLayout[], x: number, y: number): number | null {
  let best: number | null = null;
  let bestD = Infinity;
  for (const v of layouts) {
    const hitW = Math.max(v.w + 18, 48);
    const hitH = v.h + 28;
    if (Math.abs(x - v.x) > hitW / 2) continue;
    if (y < v.y - 20 || y > v.y + hitH) continue;
    const d = Math.abs(x - v.x);
    if (d < bestD) {
      bestD = d;
      best = v.index;
    }
  }
  return best;
}

function easeOut(t: number) {
  return 1 - (1 - t) * (1 - t);
}

export function drawScene(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  frame: DrawFrame,
): VialLayout[] {
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = INK;
  ctx.fillRect(0, 0, w, h);

  const lamp = ctx.createRadialGradient(w * 0.5, h * 0.08, 10, w * 0.5, h * 0.2, w * 0.7);
  lamp.addColorStop(0, "rgba(231,162,74,0.22)");
  lamp.addColorStop(0.45, "rgba(196,55,90,0.05)");
  lamp.addColorStop(1, "rgba(20,14,22,0)");
  ctx.fillStyle = lamp;
  ctx.fillRect(0, 0, w, h);

  const side = ctx.createRadialGradient(w * 0.15, h * 0.8, 10, w * 0.2, h * 0.7, w * 0.45);
  side.addColorStop(0, "rgba(31,154,108,0.07)");
  side.addColorStop(1, "rgba(20,14,22,0)");
  ctx.fillStyle = side;
  ctx.fillRect(0, 0, w, h);

  const layouts = layoutVials(frame.slugs.length, w, h);
  const lift = 14;

  for (const box of layouts) {
    const selected = frame.selected === box.index;
    const dy = selected ? -lift : 0;
    const sx =
      frame.shakeIndex === box.index ? Math.sin(frame.shakeP * 18) * 7 * frame.shakeP : 0;
    ctx.save();
    ctx.translate(sx, dy);
    const hinted =
      frame.hint !== null && (frame.hint.from === box.index || frame.hint.to === box.index);
    drawVial(ctx, box, frame.slugs[box.index] ?? [], {
      sealed: frame.sealed[box.index] ?? false,
      selected,
      hinted,
      time: frame.time,
      cork:
        frame.corkIndex === box.index && frame.corkP !== null
          ? frame.corkP
          : frame.sealed[box.index]
            ? 1
            : 0,
    });
    ctx.restore();
  }

  if (frame.stream) {
    const a = layouts[frame.stream.from];
    const b = layouts[frame.stream.to];
    if (a && b) drawStream(ctx, a, b, frame.stream.color, frame.stream.p, frame.time, frame.selected);
  }

  if (frame.won) {
    const motes = 18;
    for (let i = 0; i < motes; i++) {
      const p = (frame.time * 0.08 + i / motes) % 1;
      const x = ((i * 97) % 100) / 100 * w;
      const y = h - p * h * 0.7;
      ctx.globalAlpha = 0.25 * (1 - p);
      ctx.fillStyle = i % 2 === 0 ? LAMP : "#ff9ab4";
      ctx.beginPath();
      ctx.arc(x, y, 2.2 + (i % 3), 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }
  }

  return layouts;
}

function drawStream(
  ctx: CanvasRenderingContext2D,
  a: VialLayout,
  b: VialLayout,
  color: number,
  p: number,
  time: number,
  selected: number | null,
) {
  const ink = MELASSES[color] ?? MELASSES[0];
  const ay = a.y + 8 + (selected === a.index ? -14 : 0);
  const by = b.y + 10 + (selected === b.index ? -14 : 0);
  const x1 = a.x;
  const y1 = ay;
  const x2 = b.x;
  const y2 = by;
  const cx = (x1 + x2) / 2;
  const cy = Math.max(y1, y2) + 36 + Math.sin(time * 3) * 2;
  ctx.save();
  ctx.lineCap = "round";
  ctx.strokeStyle = ink.deep;
  ctx.lineWidth = 16;
  ctx.globalAlpha = 0.9;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.quadraticCurveTo(cx, cy, x2, y2);
  ctx.stroke();
  ctx.strokeStyle = ink.fill;
  ctx.lineWidth = 10;
  ctx.stroke();
  ctx.strokeStyle = ink.light;
  ctx.globalAlpha = 0.55;
  ctx.lineWidth = 4;
  ctx.stroke();
  for (let i = 0; i < 3; i++) {
    const t = Math.min(1, Math.max(0, p - i * 0.08));
    const u = 1 - t;
    const x = u * u * x1 + 2 * u * t * cx + t * t * x2;
    const y = u * u * y1 + 2 * u * t * cy + t * t * y2;
    ctx.globalAlpha = 0.85;
    ctx.fillStyle = ink.fill;
    ctx.beginPath();
    ctx.ellipse(x, y, 8, 6, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

type VialStyle = {
  sealed: boolean;
  selected: boolean;
  hinted: boolean;
  time: number;
  cork: number;
};

function glassPath(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
  const neckW = w * 0.46;
  const neckH = Math.min(26, h * 0.11);
  const left = x - w / 2;
  const right = x + w / 2;
  const nL = x - neckW / 2;
  const nR = x + neckW / 2;
  const bodyTop = y + neckH;
  const bot = y + h;
  const r = Math.min(w * 0.42, (bot - bodyTop) * 0.45);
  ctx.beginPath();
  ctx.moveTo(nL, y + 7);
  ctx.quadraticCurveTo(nL, y, x, y + 1);
  ctx.quadraticCurveTo(nR, y, nR, y + 7);
  ctx.lineTo(nR, bodyTop + 2);
  ctx.bezierCurveTo(right - 2, bodyTop - 2, right, bodyTop + 8, right, bodyTop + 16);
  ctx.lineTo(right, bot - r);
  ctx.quadraticCurveTo(right, bot, right - r, bot);
  ctx.lineTo(left + r, bot);
  ctx.quadraticCurveTo(left, bot, left, bot - r);
  ctx.lineTo(left, bodyTop + 16);
  ctx.bezierCurveTo(left, bodyTop + 8, left + 2, bodyTop - 2, nL, bodyTop + 2);
  ctx.closePath();
}

function innerBox(box: VialLayout) {
  const neckH = Math.min(26, box.h * 0.11);
  const wall = Math.max(5, box.w * 0.12);
  return {
    left: box.x - box.w / 2 + wall,
    right: box.x + box.w / 2 - wall,
    top: box.y + neckH + 8,
    bottom: box.y + box.h - wall - 2,
  };
}

function drawVial(
  ctx: CanvasRenderingContext2D,
  box: VialLayout,
  slugs: Slug[],
  style: VialStyle,
) {
  if (style.selected) {
    ctx.save();
    ctx.shadowColor = "rgba(231,162,74,0.55)";
    ctx.shadowBlur = 18;
    glassPath(ctx, box.x, box.y, box.w, box.h);
    ctx.fillStyle = "rgba(231,162,74,0.08)";
    ctx.fill();
    ctx.restore();
  }

  ctx.save();
  glassPath(ctx, box.x, box.y, box.w, box.h);
  ctx.clip();
  const inner = innerBox(box);
  const innerH = inner.bottom - inner.top;
  const slot = innerH / CAPACITY;
  let yCursor = inner.bottom;
  for (let i = 0; i < slugs.length; i++) {
    const slug = slugs[i];
    const segH = slot * slug.h;
    const y = yCursor - segH;
    drawSlug(ctx, inner.left, y, inner.right - inner.left, segH + 1.5, slug, style.time, i);
    yCursor = y;
  }
  ctx.restore();

  glassPath(ctx, box.x, box.y, box.w, box.h);
  ctx.strokeStyle = style.hinted ? LAMP : "rgba(246,236,223,0.55)";
  ctx.lineWidth = style.hinted ? 2.4 : 1.6;
  ctx.stroke();

  ctx.save();
  glassPath(ctx, box.x, box.y, box.w, box.h);
  ctx.clip();
  const g = ctx.createLinearGradient(box.x - box.w / 2, 0, box.x + box.w / 2, 0);
  g.addColorStop(0, "rgba(255,255,255,0.28)");
  g.addColorStop(0.18, "rgba(255,255,255,0.05)");
  g.addColorStop(0.72, "rgba(255,255,255,0)");
  g.addColorStop(1, "rgba(0,0,0,0.18)");
  ctx.fillStyle = g;
  ctx.fillRect(box.x - box.w / 2, box.y, box.w, box.h);
  ctx.restore();

  ctx.beginPath();
  ctx.ellipse(box.x, box.y + 4, box.w * 0.2, 3.2, 0, 0, Math.PI * 2);
  ctx.strokeStyle = "rgba(246,236,223,0.7)";
  ctx.lineWidth = 1.4;
  ctx.stroke();

  if (style.cork > 0.01) {
    const t = easeOut(Math.min(1, style.cork));
    const neckW = box.w * 0.34;
    const corkH = 14;
    const y = box.y - 2 + (1 - t) * -18;
    ctx.save();
    ctx.fillStyle = "#8a5a32";
    roundRect(ctx, box.x - neckW / 2, y, neckW, corkH, 3);
    ctx.fill();
    ctx.fillStyle = "rgba(255,220,170,0.35)";
    ctx.fillRect(box.x - neckW / 2 + 2, y + 2, 3, corkH - 4);
    ctx.restore();
  }

  if (style.selected) {
    ctx.fillStyle = PARCHMENT;
    ctx.globalAlpha = 0.8;
    ctx.font = "12px Outfit, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("verse", box.x, box.y + box.h + 16);
    ctx.globalAlpha = 1;
  }
}

function drawSlug(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  slug: Slug,
  time: number,
  index: number,
) {
  if (slug.hidden) {
    const g = ctx.createLinearGradient(x, y, x, y + h);
    g.addColorStop(0, "rgba(214,196,214,0.55)");
    g.addColorStop(1, "rgba(90,70,100,0.72)");
    ctx.fillStyle = g;
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = "rgba(246,236,223,0.25)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x + 6, y + h * 0.5);
    ctx.bezierCurveTo(x + w * 0.3, y + 4, x + w * 0.7, y + h - 4, x + w - 6, y + h * 0.45);
    ctx.stroke();
    return;
  }
  const ink = MELASSES[slug.color] ?? MELASSES[0];
  const g = ctx.createLinearGradient(x, y, x, y + h);
  g.addColorStop(0, ink.light);
  g.addColorStop(0.35, ink.fill);
  g.addColorStop(1, ink.deep);
  ctx.fillStyle = g;
  ctx.fillRect(x, y, w, h);

  const wave = Math.sin(time * 1.6 + index) * 2;
  ctx.fillStyle = ink.light;
  ctx.globalAlpha = 0.45;
  ctx.beginPath();
  ctx.ellipse(x + w * 0.5 + wave, y + 3, w * 0.36, 4.5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 0.18;
  ctx.beginPath();
  ctx.ellipse(x + w * 0.35, y + h * 0.55, w * 0.16, h * 0.22, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;
  drawMotif(ctx, x, y, w, h, ink.deep, ink.motif, time, index);
}

function drawMotif(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  color: string,
  motif: (typeof MELASSES)[number]["motif"],
  time: number,
  index: number,
) {
  ctx.save();
  ctx.beginPath();
  ctx.rect(x, y, w, h);
  ctx.clip();
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.globalAlpha = 0.28;
  ctx.lineWidth = 1.2;
  if (motif === "bubble") {
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.arc(x + w * (0.3 + i * 0.2), y + h * 0.45 + Math.sin(time + i) * 1.5, 2.4, 0, Math.PI * 2);
      ctx.stroke();
    }
  } else if (motif === "slash") {
    for (let i = -1; i < 4; i++) {
      ctx.beginPath();
      ctx.moveTo(x + i * 12, y + h);
      ctx.lineTo(x + i * 12 + 10, y);
      ctx.stroke();
    }
  } else if (motif === "dot") {
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) {
        ctx.beginPath();
        ctx.arc(x + 8 + c * (w / 3.2), y + 6 + r * (h / 3.2), 1.5, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  } else if (motif === "chevron") {
    ctx.beginPath();
    ctx.moveTo(x + 6, y + h * 0.65);
    ctx.lineTo(x + w / 2, y + h * 0.35);
    ctx.lineTo(x + w - 6, y + h * 0.65);
    ctx.stroke();
  } else if (motif === "ring") {
    ctx.beginPath();
    ctx.ellipse(x + w / 2, y + h / 2, w * 0.18, Math.min(8, h * 0.28), 0, 0, Math.PI * 2);
    ctx.stroke();
  } else if (motif === "wave") {
    ctx.beginPath();
    ctx.moveTo(x + 4, y + h * 0.5);
    ctx.bezierCurveTo(x + w * 0.3, y + h * 0.2, x + w * 0.6, y + h * 0.8, x + w - 4, y + h * 0.45);
    ctx.stroke();
  } else if (motif === "speck") {
    for (let i = 0; i < 7; i++) {
      const px = x + ((i * 17 + index * 5) % Math.max(8, w - 4));
      const py = y + ((i * 13) % Math.max(6, h - 4));
      ctx.fillRect(px, py, 1.6, 1.6);
    }
  } else {
    ctx.beginPath();
    ctx.moveTo(x + w / 2, y + 4);
    ctx.lineTo(x + w / 2 + 4, y + h / 2);
    ctx.lineTo(x + w / 2, y + h - 4);
    ctx.lineTo(x + w / 2 - 4, y + h / 2);
    ctx.closePath();
    ctx.stroke();
  }
  ctx.restore();
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
