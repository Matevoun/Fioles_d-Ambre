/*
 * DOCTRINE OBLIGATOIRE
 * Avant toute modification de ce jeu (humain ou IA), lire doc/DOCTRINE.md
 * Ne pas changer la regle unique. Ne pas monetiser. Ne pas retirer les credits.
 * Version : 1
 */

import { useEffect, useRef, useState, type PointerEvent } from "react";
import { Info, Lightbulb, RotateCcw, Undo2, Volume2, VolumeX } from "lucide-react";
import { DOCTRINE_VERSION } from "../game/doctrine";
import { createMixer, type Mixer } from "../game/audio";
import { drawScene, hitTest, type VialLayout } from "../game/draw";
import {
  cloneVials,
  generateLevel,
  hintMove,
  isSealed,
  isWon,
  legalMoves,
  pour,
  slugsAfterShave,
  slugsGrow,
  specFor,
  type Spec,
  type Vial,
} from "../game/logic";

const SAVE_KEY = "fioles-ambre-v1";

type Phase = "title" | "play" | "won";

type Model = {
  level: number;
  unlocked: number;
  vials: Vial[];
  initial: Vial[];
  past: Vial[][];
  moves: number;
  spec: Spec;
  selected: number | null;
  hint: { from: number; to: number } | null;
  note: string | null;
  phase: Phase;
  seen: boolean;
  muted: boolean;
};

type PourAnim = {
  kind: "pour";
  from: number;
  to: number;
  color: number;
  k: number;
  before: Vial[];
  after: Vial[];
  t0: number;
  dur: number;
  seals: boolean;
};

type ShakeAnim = { kind: "shake"; index: number; t0: number };

function fresh(level: number, unlocked: number, phase: Phase, seen: boolean, muted: boolean): Model {
  const made = generateLevel(level);
  return {
    level,
    unlocked,
    vials: cloneVials(made.vials),
    initial: cloneVials(made.vials),
    past: [],
    moves: 0,
    spec: made.spec,
    selected: null,
    hint: null,
    note: null,
    phase,
    seen,
    muted,
  };
}

function labelOf(spec: Spec): string {
  const mel = `${spec.colors} mélasses`;
  const empty = spec.empties > 1 ? `${spec.empties} fioles vides` : "une fiole vide";
  return spec.hidden ? `${mel}, ${empty}, couches voilées` : `${mel}, ${empty}`;
}

function ease(t: number) {
  const x = Math.min(1, Math.max(0, t));
  return x * x * (3 - 2 * x);
}

export function FiolesGame() {
  const [model, setModel] = useState<Model>(() => fresh(1, 1, "title", false, false));
  const [about, setAbout] = useState(false);
  const modelRef = useRef(model);
  modelRef.current = model;
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const layoutsRef = useRef<VialLayout[]>([]);
  const animRef = useRef<PourAnim | ShakeAnim | null>(null);
  const mixerRef = useRef<Mixer | null>(null);
  const readyRef = useRef(false);
  const reduceRef = useRef(false);
  const armRef = useRef(0);

  function mixer() {
    if (!mixerRef.current) mixerRef.current = createMixer();
    return mixerRef.current;
  }

  function commit(next: Model) {
    modelRef.current = next;
    setModel(next);
  }

  useEffect(() => {
    reduceRef.current = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const raw = localStorage.getItem(SAVE_KEY);
    if (raw) {
      const loaded = parseSave(raw);
      if (loaded) {
        modelRef.current = loaded;
        setModel(loaded);
      }
    }
  }, []);

  useEffect(() => {
    if (!readyRef.current) {
      readyRef.current = true;
      return;
    }
    localStorage.setItem(SAVE_KEY, JSON.stringify(toSave(model)));
  }, [model]);

  useEffect(() => {
    const onVis = () => {
      if (document.visibilityState === "visible") mixer().unlock();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || model.phase === "title") return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let frame = 0;
    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      canvas.width = Math.max(1, Math.floor(w * dpr));
      canvas.height = Math.max(1, Math.floor(h * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);
    resize();

    const loop = (now: number) => {
      const anim = animRef.current;
      let shakeIndex: number | null = null;
      let shakeP = 0;
      if (anim?.kind === "shake") {
        const p = 1 - (now - anim.t0) / 380;
        if (p <= 0) animRef.current = null;
        else {
          shakeIndex = anim.index;
          shakeP = p;
        }
      }
      if (anim?.kind === "pour") {
        const p = (now - anim.t0) / anim.dur;
        if (p >= 1) finishPour(anim);
      }
      const current = modelRef.current;
      const live = animRef.current;
      const slugs = current.vials.map((v) => slugsAfterShave(v, 0));
      let stream: { from: number; to: number; color: number; p: number } | null = null;
      let corkIndex: number | null = null;
      let corkP: number | null = null;
      if (live?.kind === "pour") {
        const p = ease((now - live.t0) / live.dur);
        for (let i = 0; i < slugs.length; i++) {
          if (i === live.from) slugs[i] = slugsAfterShave(live.before[i], live.k * p);
          else if (i === live.to) slugs[i] = slugsGrow(live.before[i], live.color, live.k * p);
          else slugs[i] = slugsAfterShave(live.before[i], 0);
        }
        stream = { from: live.from, to: live.to, color: live.color, p };
        if (live.seals) {
          corkIndex = live.to;
          corkP = Math.min(1, Math.max(0, (p - 0.62) / 0.38));
        }
      }
      const sealed = (live?.kind === "pour" ? live.before : current.vials).map((v, i) => {
        if (live?.kind === "pour" && i === live.to) return false;
        return isSealed(live?.kind === "pour" ? live.before[i] : v);
      });
      layoutsRef.current = drawScene(ctx, canvas.clientWidth, canvas.clientHeight, {
        slugs,
        sealed,
        selected: current.selected,
        shakeIndex,
        shakeP,
        hint: current.hint,
        stream,
        corkIndex,
        corkP,
        time: now / 1000,
        won: current.phase === "won",
      });
      frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(frame);
      ro.disconnect();
    };
    // The loop reads refs. Restart only when entering or leaving the board.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [model.phase === "title"]);

  function finishPour(anim: PourAnim) {
    if (animRef.current !== anim) return;
    animRef.current = null;
    const m = modelRef.current;
    const won = isWon(anim.after);
    const sound = mixer();
    if (anim.seals) sound.cork();
    if (won) sound.win();
    const stuck = !won && legalMoves(anim.after).length === 0;
    commit({
      ...m,
      vials: anim.after,
      past: [...m.past, cloneVials(anim.before)].slice(-80),
      moves: m.moves + 1,
      selected: null,
      hint: null,
      phase: won ? "won" : "play",
      unlocked: won ? Math.max(m.unlocked, m.level + 1) : m.unlocked,
      note: stuck ? "Rien ne se verse. Annule un coup, ou recommence." : null,
    });
  }

  function shake(index: number) {
    animRef.current = { kind: "shake", index, t0: performance.now() };
    mixer().deny();
  }

  function choose(index: number) {
    const m = modelRef.current;
    if (m.phase !== "play") return;
    if (animRef.current?.kind === "pour") return;
    mixer().unlock();
    const vial = m.vials[index];
    if (m.selected === null) {
      if (!vial || vial.length === 0 || isSealed(vial)) {
        shake(index);
        return;
      }
      mixer().select();
      commit({ ...m, selected: index, note: null });
      return;
    }
    if (m.selected === index) {
      commit({ ...m, selected: null });
      return;
    }
    const after = pour(m.vials, m.selected, index, true);
    if (!after) {
      shake(index);
      return;
    }
    const src = m.vials[m.selected];
    const color = src[src.length - 1].color;
    const k = after[index].length - m.vials[index].length;
    mixer().pour();
    animRef.current = {
      kind: "pour",
      from: m.selected,
      to: index,
      color,
      k,
      before: cloneVials(m.vials),
      after,
      t0: performance.now(),
      dur: reduceRef.current ? 40 : 700,
      seals: isSealed(after[index]),
    };
    commit({ ...m, selected: null, hint: null, note: null });
  }

  function onPointer(e: PointerEvent<HTMLCanvasElement>) {
    if (performance.now() < armRef.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const hit = hitTest(layoutsRef.current, e.clientX - rect.left, e.clientY - rect.top);
    if (hit === null) {
      const m = modelRef.current;
      if (m.selected !== null) commit({ ...m, selected: null });
      return;
    }
    choose(hit);
  }

  function undo() {
    const m = modelRef.current;
    if (m.phase === "title" || animRef.current?.kind === "pour" || m.past.length === 0) return;
    mixer().unlock();
    const past = m.past.slice(0, -1);
    const vials = cloneVials(m.past[m.past.length - 1]);
    commit({
      ...m,
      vials,
      past,
      moves: Math.max(0, m.moves - 1),
      selected: null,
      hint: null,
      note: null,
      phase: "play",
    });
  }

  function restart() {
    const m = modelRef.current;
    if (animRef.current?.kind === "pour") return;
    mixer().unlock();
    animRef.current = null;
    commit({
      ...m,
      vials: cloneVials(m.initial),
      past: [],
      moves: 0,
      selected: null,
      hint: null,
      note: null,
      phase: "play",
    });
  }

  function go(level: number) {
    const m = modelRef.current;
    if (level < 1 || level > m.unlocked) return;
    if (animRef.current?.kind === "pour") return;
    animRef.current = null;
    mixer().unlock();
    commit(fresh(level, m.unlocked, "play", true, m.muted));
  }

  function hint() {
    const m = modelRef.current;
    if (m.phase !== "play" || animRef.current?.kind === "pour") return;
    mixer().unlock();
    const move = hintMove(m.vials);
    if (!move) {
      commit({ ...m, note: "Rien ne se verse. Annule un coup, ou recommence.", hint: null });
      return;
    }
    commit({ ...m, hint: move, selected: move.from, note: "Essaie ce versement." });
  }

  function toggleMute() {
    const m = modelRef.current;
    const muted = !m.muted;
    mixer().unlock();
    mixer().setMuted(muted);
    commit({ ...m, muted });
  }

  function start() {
    const m = modelRef.current;
    armRef.current = performance.now() + 450;
    mixer().unlock();
    mixer().setMuted(m.muted);
    commit({ ...m, phase: "play", seen: true });
  }

  const coups = model.moves === 1 ? "1 coup" : `${model.moves} coups`;

  return (
    <main className="stage" data-doctrine={DOCTRINE_VERSION}>
      {model.phase === "title" ? (
        <section className="title-card">
          <p className="eyebrow">Pour Ambre</p>
          <h1>Fioles d'Ambre</h1>
          <p className="rule">
            Verse une mélasse seulement sur la même couleur, ou dans une fiole vide. Une fiole pleine
            d'une seule couleur se bouche.
          </p>
          <button type="button" className="btn primary" onClick={start}>
            Commencer
          </button>
          <button type="button" className="btn ghost" onClick={() => setAbout(true)}>
            À propos
          </button>
        </section>
      ) : (
        <>
          <header className="topbar">
            <div>
              <p className="mark">Fioles d'Ambre</p>
              <h1>
                Niveau {model.level}
                <span> {coups}</span>
              </h1>
              <p className="band">{labelOf(model.spec)}</p>
            </div>
            <button type="button" className="icon-btn" onClick={toggleMute} aria-label={model.muted ? "Son" : "Silence"}>
              {model.muted ? <VolumeX /> : <Volume2 />}
            </button>
          </header>
          {model.note ? <p className="note">{model.note}</p> : <p className="note quiet">Touche une fiole, puis une autre.</p>}
          <div className="play-canvas">
            <canvas ref={canvasRef} onPointerDown={onPointer} />
          </div>
          <footer className="dock">
            <button type="button" className="btn" onClick={undo} disabled={model.past.length === 0}>
              <Undo2 /> Annuler
            </button>
            <button type="button" className="btn" onClick={restart}>
              <RotateCcw /> Recommencer
            </button>
            <button type="button" className="btn" onClick={hint}>
              <Lightbulb /> Indice
            </button>
            <button type="button" className="btn" onClick={() => setAbout(true)}>
              <Info /> À propos
            </button>
          </footer>
        </>
      )}

      {model.phase === "won" && (
        <div className="veil" role="dialog" aria-modal="true" aria-labelledby="won-title">
          <div className="card">
            <h2 id="won-title">C'est rangé.</h2>
            <p>
              Niveau {model.level}, {coups}.
            </p>
            <button type="button" className="btn primary" onClick={() => go(model.level + 1)}>
              Niveau suivant
            </button>
            <button type="button" className="btn" onClick={restart}>
              Revoir
            </button>
          </div>
        </div>
      )}

      {about && (
        <div className="veil" role="dialog" aria-modal="true" aria-labelledby="about-title">
          <div className="card about">
            <h2 id="about-title">À propos et crédits</h2>
            <p className="credits">
              Développé <strong>bénévolement</strong> par{" "}
              <a href="https://mathieu.charreyre.net" target="_blank" rel="noreferrer">
                Mathieu CHARREYRE
              </a>{" "}
              pour l'
              <a href="https://wda-fr.org" target="_blank" rel="noreferrer">
                Association WDA
              </a>
              .
            </p>
            <p>
              Le prénom du jeu est celui d'Ambre. Licence : partage à l'identique, pas de
              commercialisation, citer les crédits.
            </p>
            <p>Si ce jeu vous est utile, un don à l'association suffit. Rien n'est obligatoire.</p>
            <p className="links">
              <a
                href="https://www.helloasso.com/associations/association-wda/formulaires/1"
                target="_blank"
                rel="noreferrer"
              >
                HelloAsso
              </a>
              <a
                href="https://www.paypal.com/donate/?hosted_button_id=DZRY58WUANTAJ"
                target="_blank"
                rel="noreferrer"
              >
                PayPal
              </a>
            </p>
            <button type="button" className="btn primary" onClick={() => setAbout(false)}>
              Fermer
            </button>
          </div>
        </div>
      )}
    </main>
  );
}

function toSave(m: Model) {
  return {
    v: 1 as const,
    level: m.level,
    unlocked: m.unlocked,
    moves: m.moves,
    vials: m.vials,
    initial: m.initial,
    past: m.past,
    seen: m.seen,
    muted: m.muted,
    phase: m.phase === "title" ? "title" : "play",
  };
}

function isVial(value: unknown): value is Vial {
  if (!Array.isArray(value)) return false;
  return value.every(
    (s) =>
      s &&
      typeof s === "object" &&
      typeof (s as { color?: unknown }).color === "number" &&
      typeof (s as { hidden?: unknown }).hidden === "boolean",
  );
}

function parseSave(raw: string): Model | null {
  try {
    const data = JSON.parse(raw) as {
      v?: number;
      level?: number;
      unlocked?: number;
      moves?: number;
      vials?: unknown;
      initial?: unknown;
      past?: unknown;
      seen?: boolean;
      muted?: boolean;
    };
    if (data.v !== 1 || typeof data.level !== "number") return null;
    const level = Math.max(1, Math.floor(data.level));
    const spec = specFor(level);
    if (!Array.isArray(data.vials) || !Array.isArray(data.initial)) return null;
    if (!data.vials.every(isVial) || !data.initial.every(isVial)) return null;
    if (data.vials.length !== spec.colors + spec.empties) return null;
    const past = Array.isArray(data.past) ? data.past.filter(isVialArray) : [];
    const unlocked = Math.max(level, typeof data.unlocked === "number" ? Math.floor(data.unlocked) : level);
    return {
      level,
      unlocked,
      vials: data.vials,
      initial: data.initial,
      past: past.slice(-80),
      moves: typeof data.moves === "number" ? data.moves : 0,
      spec,
      selected: null,
      hint: null,
      note: null,
      phase: data.seen ? "play" : "title",
      seen: Boolean(data.seen),
      muted: Boolean(data.muted),
    };
  } catch {
    return null;
  }
}

function isVialArray(value: unknown): value is Vial[] {
  return Array.isArray(value) && value.every(isVial);
}
