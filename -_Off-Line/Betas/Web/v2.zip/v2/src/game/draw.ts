/*
 * DOCTRINE OBLIGATOIRE
 * Avant toute modification de ce jeu (humain ou IA), lire doc/DOCTRINE.md
 * Ne pas changer la regle unique. Ne pas monetiser. Ne pas retirer les credits.
 * Version : 1
 * Jeu : 0.2
 *
 * La paroi est l'image fiole.png (interieur transparent).
 * La melasse est dessinee dessous, lisse, sans motif.
 * Le CSS Meta (liquide dessous, verre dessus, pointer-events none)
 * est le meme principe, fait ici sur le canvas : une image fixe ne verse pas.
 */

import { CAPACITY, MELASSES, type Slug } from "./logic";
import vialUrl from "./fiole.png";

export type VialLayout = {
  index: number;
  x: number;
  y: number;
  w: number;
  h: number;
};

export type DrawFrame = {
  slugs: Slug[][];
  sealed: boolean[];
  selected: number | null;
  shakeIndex: number | null;
  shakeP: number;
  hint: { from: number; to: number } | null;
  stream: { from: number; to: number; color: number; p: number } | null;
  corkP: number | null;
  corkIndex: number | null;
  time: number;
  won: boolean;
};

const INK = "#140e16";
const LAMP = "#e7a24a";
const PARCHMENT = "#f6ecdf";

export function layoutVials(count: number, w: number, h: number): VialLayout[] {
  const rows = count > 6 ? 2 : 1;
  const cols = Math.ceil(count / rows);
  const padX = 14;
  const padY = 16;
  const slotW = (w - padX * 2) / cols;
  const slotH = (h - padY * 2) / rows;
  let vialW = Math.min(slotW * 0.98, 150);
  let vialH = vialW * 2;
  if (vialH > slotH * 0.96) {
    vialH = slotH * 0.96;
    vialW = vialH / 2;
  }
  const out: VialLayout[] = [];
  for (let i = 0; i < count; i++) {
    const row = Math.floor(i / cols);
    const col = i % cols;
    const inRow = Math.min(cols, count - row * cols);
    const rowWidth = inRow * slotW;
    const originX = (w - rowWidth) / 2;
    out.push({
      index: i,
      x: originX + col * slotW + slotW / 2,
      y: padY + row * slotH + (slotH - vialH) / 2,
      w: vialW,
      h: vialH,
    });
  }
  return out;
}

export function hitTest(layouts: VialLayout[], x: number, y: number): number | null {
  let best: number | null = null;
  let bestD = Infinity;
  for (const v of layouts) {
    const hitW = Math.max(v.w + 18, 48);
    const hitH = v.h + 28;
    if (Math.abs(x - v.x) > hitW / 2) continue;
    if (y < v.y - 20 || y > v.y + hitH) continue;
    const d = Math.abs(x - v.x);
    if (d < bestD) {
      bestD = d;
      best = v.index;
    }
  }
  return best;
}

function easeOut(t: number) {
  return 1 - (1 - t) * (1 - t);
}

export function drawScene(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  frame: DrawFrame,
): VialLayout[] {
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = INK;
  ctx.fillRect(0, 0, w, h);

  const lamp = ctx.createRadialGradient(w * 0.5, h * 0.08, 10, w * 0.5, h * 0.2, w * 0.7);
  lamp.addColorStop(0, "rgba(231,162,74,0.22)");
  lamp.addColorStop(0.45, "rgba(196,55,90,0.05)");
  lamp.addColorStop(1, "rgba(20,14,22,0)");
  ctx.fillStyle = lamp;
  ctx.fillRect(0, 0, w, h);

  const side = ctx.createRadialGradient(w * 0.15, h * 0.8, 10, w * 0.2, h * 0.7, w * 0.45);
  side.addColorStop(0, "rgba(31,154,108,0.07)");
  side.addColorStop(1, "rgba(20,14,22,0)");
  ctx.fillStyle = side;
  ctx.fillRect(0, 0, w, h);

  const layouts = layoutVials(frame.slugs.length, w, h);
  const lift = 14;

  for (const box of layouts) {
    const selected = frame.selected === box.index;
    const dy = selected ? -lift : 0;
    const sx =
      frame.shakeIndex === box.index ? Math.sin(frame.shakeP * 18) * 7 * frame.shakeP : 0;
    ctx.save();
    ctx.translate(sx, dy);
    const hinted =
      frame.hint !== null && (frame.hint.from === box.index || frame.hint.to === box.index);
    drawVial(ctx, box, frame.slugs[box.index] ?? [], {
      sealed: frame.sealed[box.index] ?? false,
      selected,
      hinted,
      time: frame.time,
      cork:
        frame.corkIndex === box.index && frame.corkP !== null
          ? frame.corkP
          : frame.sealed[box.index]
            ? 1
            : 0,
    });
    ctx.restore();
  }

  if (frame.stream) {
    const a = layouts[frame.stream.from];
    const b = layouts[frame.stream.to];
    if (a && b) drawStream(ctx, a, b, frame.stream.color, frame.stream.p, frame.time, frame.selected);
  }

  if (frame.won) {
    const motes = 18;
    for (let i = 0; i < motes; i++) {
      const p = (frame.time * 0.08 + i / motes) % 1;
      const x = ((i * 97) % 100) / 100 * w;
      const y = h - p * h * 0.7;
      ctx.globalAlpha = 0.25 * (1 - p);
      ctx.fillStyle = i % 2 === 0 ? LAMP : "#ff9ab4";
      ctx.beginPath();
      ctx.arc(x, y, 2.2 + (i % 3), 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }
  }

  return layouts;
}

function drawStream(
  ctx: CanvasRenderingContext2D,
  a: VialLayout,
  b: VialLayout,
  color: number,
  p: number,
  time: number,
  selected: number | null,
) {
  const ink = MELASSES[color] ?? MELASSES[0];
  const shown = 0.35 + 0.65 * Math.min(1, Math.max(0, p));
  const ay = a.y + a.h * 0.07 + (selected === a.index ? -14 : 0);
  const by = b.y + b.h * 0.08 + (selected === b.index ? -14 : 0);
  const x1 = a.x;
  const y1 = ay;
  const x2 = b.x;
  const y2 = by;
  const cx = (x1 + x2) / 2;
  const cy = Math.min(y1, y2) - 28 + Math.sin(time * 2.2) * 1.5;
  const sag = Math.abs(x2 - x1) * 0.18;
  ctx.save();
  ctx.lineCap = "round";
  ctx.strokeStyle = ink.deep;
  ctx.lineWidth = 18;
  ctx.globalAlpha = 0.95 * shown;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.quadraticCurveTo(cx, cy + sag, x2, y2);
  ctx.stroke();
  ctx.strokeStyle = ink.fill;
  ctx.lineWidth = 12;
  ctx.stroke();
  ctx.strokeStyle = ink.light;
  ctx.globalAlpha = 0.4 * shown;
  ctx.lineWidth = 3.5;
  ctx.stroke();
  ctx.restore();
}

type VialStyle = {
  sealed: boolean;
  selected: boolean;
  hinted: boolean;
  time: number;
  cork: number;
};

const INNER_L = 142 / 512;
const INNER_R = 370 / 512;
const INNER_T = 168 / 1024;
const INNER_B = 985 / 1024;

let vialImg: HTMLImageElement | null = null;

function vialImage(): HTMLImageElement | null {
  if (typeof Image === "undefined") return null;
  if (!vialImg) {
    const img = new Image();
    img.src = vialUrl;
    vialImg = img;
  }
  return vialImg.complete && vialImg.naturalWidth > 0 ? vialImg : null;
}

function liquidBox(box: VialLayout) {
  const leftEdge = box.x - box.w / 2;
  return {
    left: leftEdge + box.w * INNER_L,
    right: leftEdge + box.w * INNER_R,
    top: box.y + box.h * INNER_T,
    bottom: box.y + box.h * INNER_B,
  };
}

function liquidPath(
  ctx: CanvasRenderingContext2D,
  inner: { left: number; right: number; top: number; bottom: number },
) {
  const r = (inner.right - inner.left) / 2;
  const cx = (inner.left + inner.right) / 2;
  const bowl = inner.bottom - r;
  ctx.beginPath();
  ctx.moveTo(inner.left, inner.top);
  ctx.lineTo(inner.left, Math.max(inner.top, bowl));
  ctx.arc(cx, Math.max(inner.top, bowl), r, Math.PI, 0, true);
  ctx.lineTo(inner.right, inner.top);
  ctx.closePath();
}

function drawVial(
  ctx: CanvasRenderingContext2D,
  box: VialLayout,
  slugs: Slug[],
  style: VialStyle,
) {
  const img = vialImage();
  const dx = box.x - box.w / 2;

  if (style.selected || style.hinted) {
    ctx.save();
    ctx.shadowColor = style.selected ? "rgba(231,162,74,0.85)" : "rgba(231,162,74,0.45)";
    ctx.shadowBlur = style.selected ? 22 : 12;
    if (img) ctx.drawImage(img, dx, box.y, box.w, box.h);
    else {
      ctx.fillStyle = "rgba(231,162,74,0.2)";
      ctx.fillRect(dx, box.y, box.w, box.h);
    }
    ctx.restore();
  }

  const inner = liquidBox(box);
  ctx.save();
  liquidPath(ctx, inner);
  ctx.clip();
  const innerH = inner.bottom - inner.top;
  const slot = innerH / CAPACITY;
  let yCursor = inner.bottom;
  for (let i = 0; i < slugs.length; i++) {
    const slug = slugs[i];
    const segH = slot * slug.h;
    const y = yCursor - segH;
    const isTop = i === slugs.length - 1;
    drawSlug(ctx, inner.left, y, inner.right - inner.left, segH, slug, isTop);
    yCursor = y;
  }
  const shade = ctx.createLinearGradient(inner.left, 0, inner.right, 0);
  shade.addColorStop(0, "rgba(255,255,255,0.2)");
  shade.addColorStop(0.16, "rgba(255,255,255,0.05)");
  shade.addColorStop(0.62, "rgba(255,255,255,0)");
  shade.addColorStop(1, "rgba(40,16,28,0.28)");
  ctx.fillStyle = shade;
  ctx.fillRect(inner.left, inner.top, inner.right - inner.left, innerH);
  ctx.restore();

  if (img) {
    ctx.drawImage(img, dx, box.y, box.w, box.h);
  } else {
    ctx.strokeStyle = "rgba(246,236,223,0.45)";
    ctx.lineWidth = 2;
    ctx.strokeRect(dx + box.w * 0.2, box.y + box.h * 0.08, box.w * 0.6, box.h * 0.86);
  }

  if (style.cork > 0.01) {
    const t = easeOut(Math.min(1, style.cork));
    const corkW = box.w * 0.26;
    const corkH = Math.max(8, box.h * 0.045);
    const y = box.y + box.h * 0.035 + (1 - t) * -box.h * 0.08;
    ctx.save();
    ctx.fillStyle = "#8d5a34";
    roundRect(ctx, box.x - corkW / 2, y, corkW, corkH, 3);
    ctx.fill();
    ctx.fillStyle = "rgba(255,214,160,0.35)";
    ctx.fillRect(box.x - corkW / 2 + 2, y + 2, Math.max(2, corkW * 0.12), corkH - 4);
    ctx.restore();
  }

  if (style.selected) {
    ctx.fillStyle = PARCHMENT;
    ctx.globalAlpha = 0.8;
    ctx.font = "12px Outfit, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("verse", box.x, box.y + box.h + 16);
    ctx.globalAlpha = 1;
  }
}

function drawSlug(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  slug: Slug,
  isTop: boolean,
) {
  if (slug.hidden) {
    const g = ctx.createLinearGradient(x, y, x, y + h);
    g.addColorStop(0, "rgba(236,226,232,0.5)");
    g.addColorStop(1, "rgba(78,60,86,0.82)");
    ctx.fillStyle = g;
    ctx.fillRect(x, y - 1, w, h + 2);
    return;
  }
  const ink = MELASSES[slug.color] ?? MELASSES[0];
  const g = ctx.createLinearGradient(x, y, x, y + h);
  g.addColorStop(0, ink.light);
  g.addColorStop(0.22, ink.fill);
  g.addColorStop(1, ink.deep);
  ctx.fillStyle = g;
  ctx.fillRect(x, y - 1, w, h + 2);
  if (!isTop) {
    ctx.globalAlpha = 0.28;
    ctx.fillStyle = ink.deep;
    ctx.fillRect(x, y, w, 2);
    ctx.globalAlpha = 1;
  } else {
    ctx.save();
    ctx.globalAlpha = 0.5;
    ctx.fillStyle = ink.light;
    ctx.beginPath();
    ctx.ellipse(x + w * 0.5, y + Math.max(2, h * 0.08), w * 0.4, Math.max(2.5, h * 0.07), 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}
