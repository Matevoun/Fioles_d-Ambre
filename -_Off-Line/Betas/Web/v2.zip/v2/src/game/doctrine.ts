/*
 * DOCTRINE OBLIGATOIRE
 * Avant toute modification de ce jeu (humain ou IA), lire doc/DOCTRINE.md
 * Ne pas changer la regle unique. Ne pas monetiser. Ne pas retirer les credits.
 * Version : 1
 * Jeu : 0.2
 */
export const DOCTRINE_FILE = "doc/DOCTRINE.md";
export const DOCTRINE_VERSION = 1;
export const GAME_VERSION = "0.2";
