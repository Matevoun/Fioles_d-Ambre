# Doctrine : Fioles d'Ambre

Doctrine version 1. Jeu version 0.2. 21 octobre 2026.

Obligation. Toute modification de ce jeu, par un humain ou par une IA, commence par la lecture de ce fichier. Le bandeau en tête des fichiers de code le rappelle. On ne le retire pas.

Le numéro de jeu visible à l'écran est 0.2. On l'incrémente quand le joueur voit un changement. On ne le cache pas.

## Identité

- Titre : **Fioles d'Ambre**.
- Clin d'oeil au prénom d'Ambre, qui aime ce genre de jeu. Le jeu public ne publie ni nom de famille, ni date, ni adresse.
- Développé bénévolement par Mathieu CHARREYRE pour l'Association WDA (https://wda-fr.org).
- Pas de prix, pas de publicité, pas de jauge d'énergie, pas de coffre, pas de compte. Si quelqu'un veut donner, il donne à la WDA.
- HelloAsso : https://www.helloasso.com/associations/association-wda/formulaires/1
- PayPal : https://www.paypal.com/donate/?hosted_button_id=DZRY58WUANTAJ
- Licence : partage à l'identique, pas de commercialisation, citer les crédits.

Le texte « À propos » reprend ces crédits. Le mot « bénévolement » reste plus grand que le corps, comme sur PixelGod.

## Règle unique

On verse le haut d'une fiole sur une autre seulement si :

1. la fiole d'arrivée est vide, ou
2. sa couleur du dessus est la même.

On verse autant d'unités de cette couleur que la place le permet. Une fiole vide ne se sélectionne pas. On ne verse pas une fiole sur elle-même.

Une fiole pleine d'une seule couleur se bouche. Ce n'est pas une seconde règle : ces unités sont déjà toutes réunies, les verser ailleurs ne sert jamais. On ne débouche pas.

Rien d'autre. Pas de bombe, pas de fiole gelée, pas de couleur joker, pas de chrono, pas de vie. La difficulté augmente, la règle non.

## Courbe

Chaque couleur a exactement 4 unités. Il y a toujours au moins une fiole vide.

| Niveaux | Couleurs | Fioles vides | Voile | Coups du chemin |
| --- | --- | --- | --- | --- |
| 1 | 3 | 2 | non | 3 |
| 2 | 3 | 2 | non | 5 |
| 3 | 3 | 2 | non | 8 |
| 4 à 6 | 4 | 2 | non | 10, 13, 16 |
| 7 à 10 | 5 | 2 | non | 12 à 18 |
| 11 à 14 | 5 | 1 | non | 10 à 14 |
| 15 à 18 | 6 | 2 | non | 14 à 20 |
| 19 à 22 | 6 | 1 | non | 12 à 18 |
| 23 à 26 | 7 | 2 | oui | 16 à 22 |
| 27 à 30 | 7 | 1 | oui | 14 à 20 |
| 31 à 34 | 8 | 2 | oui | 18 à 24 |
| 35 à 40 | 8 | 1 | oui | 16 à 22 |
| 41 et plus | 9 à 12 | 1 | oui | autour de 20 |

Le générateur part d'un tableau rangé et défait des versements légaux, à l'envers. Chaque niveau reste soluble. Le joueur peut mettre plus de coups que la ligne du tableau : c'est normal, la ligne est un chemin, pas un chrono.

Le voile cache seulement ce qui est sous la bande de couleur du dessus. On voit toujours toute la couleur versable. Quand la bande part, la bande suivante se dévoile en entier.

Annuler est illimité. L'indice est gratuit : une suggestion, pas une solution vendue. Recommencer rejoue le même mélange.

## Matières

La mélasse est épaisse, lente, lisible. Couleurs franches. Pas de bonbon criard, pas de style publicitaire vulgaire.

Pas de motif dans le liquide. Ni points, ni hachures, ni chevrons, ni vagues dessinées. Ça faisait jeu ancien. Une couleur se reconnaît à sa teinte, à un dégradé (clair en haut, foncé en bas), à un ménisque, et à un reflet vertical. Une ligne sombre très fine peut séparer deux couches, pour qu'on les compte. Rien d'autre.

La paroi de verre est une image, pas un dessin de code. Fichier : `src/game/fiole.png`, la fiole 512×1024 au fond transparent. L'intérieur est vide pour laisser voir la mélasse. On ne l'étire pas : le cadre du jeu garde le rapport 1:2 de cette image. On ne met pas en ligne les autres tailles.

Le liquide, le ménisque et le filet qui se verse restent dessinés par le code. Une image fixe ne sait pas verser. Pas de planche de sprites de liquide.

L'idée CSS proposée à part (liquide en dessous, image de verre par-dessus, le doigt traverse l'image) est juste. Elle est faite sur le canvas, pas avec ces classes : le versement, le bouchon et le toucher sont déjà là. On ne réécrit pas le jeu en blocs HTML pour trois règles CSS.

Assets utiles encore, si on en ajoute (fond transparent, vue de face, aucun texte dans l'image) :

- un fond d'atelier sombre, lampe ambrée, sans aucune fiole
- une icône : une seule fiole de verre, mélasse ambrée
- un bouchon de liège, vu de face, si celui dessiné par le code ne suffit plus
- éventuellement une goutte discrète, pour l'écran de victoire

À ne pas faire dessiner : planches de liquides, douze bouteilles différentes, texte, personnages, motifs à coller dans la mélasse.

## Portage

La version jouable est le client web, au doigt, téléphone compris. Un port Godot recopiera cette règle, cette courbe et ces crédits. Il ne les réinvente pas.

## Commentaires

Les commentaires de code restent sans accents. Le texte que lit le joueur est en français accentué.
